# main.py - Ejemplo de conexión con cTrader Open API
print("Este será el punto de entrada para conectar con la API de cTrader.")