# config_sample.py
# Renombra este archivo a config.py y completa tus credenciales de acceso a cTrader API

CLIENT_ID = "tu_client_id"
CLIENT_SECRET = "tu_client_secret"
REDIRECT_URI = "http://localhost"
CT_API_BASE_URL = "https://api.spotware.com"
