# cTrader Open API Connector

Este proyecto permite conectar estrategias en Python a cTrader usando su Open API.